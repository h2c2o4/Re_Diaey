Rails.application.routes.draw do
  root to: 'homes#top'
  get 'home/help', to: 'homes#help'
end
