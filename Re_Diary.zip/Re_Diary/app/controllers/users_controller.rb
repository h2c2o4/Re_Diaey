class UsersController < ApplicationController
  def top
  end
end
