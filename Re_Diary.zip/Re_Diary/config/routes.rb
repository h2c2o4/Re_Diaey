Rails.application.routes.draw do
  devise_for :users
  root to: 'homes#top'
  get 'home/help', to: 'homes#help'
  get 'user/top', to: 'users#top'
end
